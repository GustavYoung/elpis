v0.1.2 - 06/02/2015

- use org_freedesktop_general as default context #50 #51

Dbus proxy / web client example
========================

TODO: add docs

Code is based on sockjs/echo example

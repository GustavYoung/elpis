describe('Signature parser', function() {
  //beforeEach(function(done) {
  //});
  //afterEach(function(done) {
  //});
  //it('parses simple sequence', function(done) {
  //  var res = parse('yvsgu');
  //  // TODO: wip
  //});
});

//////////////////////////////////////////////////////////////

var adsDirPath = '/_uxmal/adplay/ads/';
var scheduleTime = '*/3 * * * * *';

//////////////////////////////////////////////////////////////

console.log('Starting');

var fs = require('fs');
var execSync = require('child_process').execSync;
var schedule = require('node-schedule');
var omxp1 = require('omxplayer-controll-ucp');
var omxp3 = require('omxplayer-controll3');
var devRes = getDevResolution();

var alpha = 1;
var volume = 0.0;
var fadeSpeed = 2;
var running = { Id: '', Omx: ''};

var opts1 = {
	'audioOutput':			'hdmi',			// 'hdmi' | 'local' | 'both'
	'blackBackground':		false,			// false | true | default: true
	'disableKeys':			true,			// false | true | default: false
	'disableOnScreenDisplay':	true,			// false | true | default: false
	'disableGhostbox':		true,			// false | true | default: false
};

if (devRes.height == 720) {
	var changeSpeed = 5;
	var vidHeight = 485;
	var winPos = '815 445 1245 695';
} else if (devRes.height == 1080) {
	var changeSpeed = 10;
	var vidHeight = 730;
	var winPos = '1230 670 1860 1030';
}

console.log('Device Resolution:', devRes);

omxp1.open('dummy', opts1);
running.Id = '1';
running.Omx = omxp1;

var job = schedule.scheduleJob(scheduleTime, function(){ showAd(getAdFile(adsDirPath)); });

omxp3.on('finish',function(){
	console.log('showAd: finished');
	changeVideoPos(running.Omx, changeSpeed, vidHeight, devRes.height);
});

function showAd(adFile) {
	console.log('showAd:', adFile);
	var opts3 = {
		'audioOutput':			'hdmi',			// 'hdmi' | 'local' | 'both'
		'blackBackground':		false,			// false | true | default: true
		'disableKeys':			true,			// false | true | default: false
		'disableOnScreenDisplay':	true,			// false | true | default: false
		'disableGhostbox':		true,			// false | true | default: false
		'subtitlePath':			'',			// default: ""
		'startAt':			0,			// default: 0
		'startVolume':			0.0,			// default: 1.0 (0.0 - 1.0)
		'alpha':			30,			// default: 254 (1 - 255)
		'layer':			5,			// default: 1
		'win':				winPos			//
	};
	running.Omx.getSource(function(err, source){
		if (typeof source !== 'undefined' && source.match(/\/uploads\/ads\//gi)) {
			console.log('showAd: a full size ad video is been played.. skipping.');
			setTimeout(function(){ showAd(getAdFile(adsDirPath)); }, 10000);
		} else {
			if (typeof source === 'undefined') {
				console.log('showAd: there is no main video been played.. playing ad in full size.');
				opts3.win = '0 0 0 0';
			}
			omxp3.open(adFile, opts3);
			setTimeout(function(){ omxp3.fadeIn(3, false, function(err){}); }, 500);
			changeVideoPos(running.Omx, changeSpeed, devRes.height, vidHeight);
		}
	});
}

function getAdFile(path) {
    if (typeof _lastAd === 'undefined') {_lastAd = '';}
    var files = fs.readdirSync(path)
    for (var i = 0; i < files.length; i++) {
        if (_lastAd == '') {
            _lastAd = files[i];
            break;
        } else if (_lastAd == files[i] && (i + 1) == files.length) {
            _lastAd = files[0];
            break;
        } else if (_lastAd == files[i] && (i + 1) < files.length) {
            _lastAd = files[i+1];
            break;
        } else {
        }
    }
    return path.replace(/\/$/gm,'') + '/' + _lastAd;
}

function changeVideoPos(id, speed, fromHeight, toHeight) {
	var ratio = 1.7777777777777777;
	var setHeight = fromHeight;
	var setWidth = (setHeight * ratio);
	if (toHeight < fromHeight) {
		if (fromHeight == 1080) {var space = 50;} else {var space = 35;}
		while (setHeight > toHeight) {
			setHeight -= speed;
			if (setHeight < toHeight) {setHeight = toHeight;}
			setWidth = (setHeight * ratio);
			id.setVideoPos(space, (space - 10), setWidth, setHeight, function(err){
				//console.log(err);
			});
		}
	} else if (toHeight >= fromHeight) {
		while (setHeight < toHeight) {
			setHeight += speed;
			if (setHeight > toHeight) {setHeight = toHeight;}
			setWidth = (setHeight * ratio);
			id.setVideoPos(0, 0, setWidth, setHeight, function(err){
				//console.log(err);
			});
		}
	}
}

function getDevResolution() {
	var width = 1920;
	var height = 1080;
	var hz = 60.00;
	try {
		var stdout = execSync('tvservice -s').toString();
		regex = /\s*?state\s*?.*\,\s+(\d+)x(\d+)\s+\@\s+([\.\d]+)Hz\,.*/;
		result = stdout.trim().match(regex);
		if (result === null) {
			console.log('getDevResolution: regex failed. (stdout: ' + stdout +')');
		} else {
			var width = result[1];
			var height = result[2];
			var hz = result[3];
		}
	} catch (error) {
		console.log('getDevResolution: exec error: \n    ' + error.toString().trim().replace('\n', ' \n    '));
	}
	return {
		width: Math.round(width),
		height: Math.round(height),
		hertz: Math.round(hz),
		hz: Math.round(hz)
	};
}
